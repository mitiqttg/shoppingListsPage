# Project 1: Shared shopping list
```!DOCTYPE HTML
This is my first project for Web Software Development course at "fitech101.aalto.fi" 
    -Main page: containting statistics of total number of lists and items created.
    -Shopping lists: all active shopping lists. You can deactivate a list by clicking on "Deactivate list!" button.
    -Single list: return a shopping list and all its items. You can add new item by clicking on "Add item" or collect it by "Mark completed!" button.
Address of the online location where my project is: https://wick.fly.dev/
If the link is not accessible, you can download the folder, open "shopping-lists" file in terminal and use "docker-compose up" to test the application locally.
```
